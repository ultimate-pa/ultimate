/**
 * Package information for the map elimination.
 *
 * @author Frank Schüssele (schuessf@informatik.uni-freiburg.de)
 *
 */
package de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.smt.mapelimination;